import { useState } from "react";
import { motion } from "framer-motion";

export default function Register() {
  const [formData, setFormData] = useState({
    name: "",
    rollNo: "",
    email: "",
    department: "",
    semester: "",
    event: "",
    message: "",
  });

  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const events = [
    "Tech Talk",
    "Hackathon",
    "AI Workshop",
    "Cyber Security Bootcamp",
    "Tech Taakra Competition",
  ];

  const validateForm = () => {
    let tempErrors = {};

    if (!formData.name.trim()) tempErrors.name = "Name is required";
    if (!formData.rollNo.trim()) tempErrors.rollNo = "Roll No is required";
    if (!formData.email.trim()) tempErrors.email = "Email is required";
    if (!formData.department.trim()) tempErrors.department = "Department is required";
    if (!formData.semester.trim()) tempErrors.semester = "Semester is required";
    if (!formData.event.trim()) tempErrors.event = "Please select an event";

    setErrors(tempErrors);

    return Object.keys(tempErrors).length === 0;
  };

 const handleSubmit = async (e) => {
  e.preventDefault();

  if (!validateForm()) return;

  try {
    await fetch("http://localhost:3001/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    });

    setSubmitted(true);

    setFormData({
      name: "",
      rollNo: "",
      email: "",
      department: "",
      semester: "",
      event: "",
      message: "",
    });

    setTimeout(() => setSubmitted(false), 4000);

  } catch (err) {
    console.error("Error submitting form:", err);
  }
};

  return (
    <div className="min-h-screen pt-28 pb-16 px-4 md:px-20 lg:px-32 bg-[#001a33] text-white relative overflow-hidden">
      {/* BACKGROUND GLOWS */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute w-80 h-80 bg-[#FFD700]/18 blur-[140px] top-10 left-6" />
        <div className="absolute w-80 h-80 bg-[#003366]/45 blur-[160px] bottom-8 right-4" />
      </div>

      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-4xl md:text-5xl font-bold text-center text-[#FFD700] drop-shadow-xl"
      >
        Event Registration
      </motion.h1>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="text-center text-gray-200 mt-3 max-w-2xl mx-auto"
      >
        Register for upcoming Computer Science Society events. Fill out the form
        below carefully with your correct academic details.
      </motion.p>

      {submitted && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-6 text-center bg-emerald-600/20 border border-emerald-400 text-emerald-200 p-3 rounded-lg max-w-xl mx-auto"
        >
          🎉 Registration successful! You will receive a confirmation via email or announcement.
        </motion.div>
      )}

      <motion.form
        onSubmit={handleSubmit}
        className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-6 bg-white/5 backdrop-blur-xl p-8 rounded-2xl border border-white/10 shadow-[0_0_30px_rgba(0,0,0,0.7)] relative z-10"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.7 }}
      >
        {/* Name */}
        <div>
          <label className="block mb-1 font-medium">Full Name</label>
          <input
            type="text"
            className="w-full p-3 rounded-lg bg-[#001427]/90 border border-white/15 focus:border-[#FFD700] outline-none text-sm"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
          />
          {errors.name && <p className="text-red-400 text-xs mt-1">{errors.name}</p>}
        </div>

        {/* Roll No */}
        <div>
          <label className="block mb-1 font-medium">Roll Number</label>
          <input
            type="text"
            className="w-full p-3 rounded-lg bg-[#001427]/90 border border-white/15 focus:border-[#FFD700] outline-none text-sm"
            value={formData.rollNo}
            onChange={(e) => setFormData({ ...formData, rollNo: e.target.value })}
          />
          {errors.rollNo && <p className="text-red-400 text-xs mt-1">{errors.rollNo}</p>}
        </div>

        {/* Email */}
        <div>
          <label className="block mb-1 font-medium">Email Address</label>
          <input
            type="email"
            className="w-full p-3 rounded-lg bg-[#001427]/90 border border-white/15 focus:border-[#FFD700] outline-none text-sm"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
          />
          {errors.email && <p className="text-red-400 text-xs mt-1">{errors.email}</p>}
        </div>

        {/* Department */}
        <div>
          <label className="block mb-1 font-medium">Department</label>
          <input
            type="text"
            className="w-full p-3 rounded-lg bg-[#001427]/90 border border-white/15 focus:border-[#FFD700] outline-none text-sm"
            value={formData.department}
            onChange={(e) => setFormData({ ...formData, department: e.target.value })}
          />
          {errors.department && <p className="text-red-400 text-xs mt-1">{errors.department}</p>}
        </div>

        {/* Semester */}
        <div>
          <label className="block mb-1 font-medium">Semester</label>
          <input
            type="text"
            className="w-full p-3 rounded-lg bg-[#001427]/90 border border-white/15 focus:border-[#FFD700] outline-none text-sm"
            value={formData.semester}
            onChange={(e) => setFormData({ ...formData, semester: e.target.value })}
          />
          {errors.semester && <p className="text-red-400 text-xs mt-1">{errors.semester}</p>}
        </div>

        {/* Event Select */}
        <div>
          <label className="block mb-1 font-medium">Select Event</label>
          <select
            className="w-full p-3 rounded-lg bg-[#001427]/90 border border-white/15 focus:border-[#FFD700] outline-none text-sm"
            value={formData.event}
            onChange={(e) => setFormData({ ...formData, event: e.target.value })}
          >
            <option value="">-- Choose an event --</option>
            {events.map((ev, index) => (
              <option key={index} value={ev}>
                {ev}
              </option>
            ))}
          </select>
          {errors.event && <p className="text-red-400 text-xs mt-1">{errors.event}</p>}
        </div>

        {/* Message */}
        <div className="md:col-span-2">
          <label className="block mb-1 font-medium">Message (Optional)</label>
          <textarea
            rows="4"
            className="w-full p-3 rounded-lg bg-[#001427]/90 border border-white/15 focus:border-[#FFD700] outline-none text-sm"
            value={formData.message}
            onChange={(e) => setFormData({ ...formData, message: e.target.value })}
          ></textarea>
        </div>

        {/* Submit */}
        <div className="md:col-span-2 flex justify-center mt-4">
          <button
            type="submit"
            className="px-10 py-3 rounded-full bg-[#FFD700] text-black font-semibold text-sm sm:text-base
                       hover:bg-yellow-400 shadow-[0_0_20px_rgba(255,215,0,0.5)] transition-all"
          >
            Submit Registration
          </button>
        </div>
      </motion.form>
    </div>
  );
}
