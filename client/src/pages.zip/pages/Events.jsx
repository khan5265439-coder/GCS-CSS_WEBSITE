import React from "react";
import { motion } from "framer-motion";
import EventCard from "../components/EventCard";

const pastEvents = [
  {
    title: "Tech Takra",
    date: "11 Nov 2025",
    description:
      "Build amazing projects with peers in 2 hours of coding frenzy!",
    image: "src/assets/images/event1.png",
  },
  {
    title: "Pure Logics Tour",
    date: "02 Nov 2025",
    description:
      "Hands-on AI and Machine Learning workshop for students.",
    image: "src/assets/images/event2.jpg",
  },
  {
    title: "Annual Trip",
    date: "30 Oct 2025",
    description:
      "Learn React, Node.js, and full-stack web development.",
    image: "src/assets/images/event3.jpg",
  },
  {
    title: "Tech talk(teacher) Series",
    date: "12 July 2025",
    description:
      "Meet industry experts and learn about emerging tech trends.",
    image: "src/assets/images/event5.jpeg",
  },
  {
    title: "Annual Dinner",
    date: "5 Aug 2025",
    description:
      "Explore the world of ethical hacking and security practices.",
    image: "src/assets/images/event4.jpg",
  },
];

const upcomingEvents = [
  {
    title: "AI Fest 2026",
    date: "10 Jan 2026",
    description:
      "A celebration of Artificial Intelligence with workshops, competitions, and project showcases.",
    image: "src/assets/images/upcoming1.jpeg",
  },
  {
    title: "Women in Tech Conference",
    date: "25 Jan 2026",
    description:
      "Empowering women in computing with inspiring sessions, networking, and mentorship.",
    image: "src/assets/images/upcoming2.jpeg",
  },
];

export default function Events() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#001a33] via-[#002244] to-[#0a0f1a] text-white px-6 py-20 max-w-6xl mx-auto">
      {/* Header */}
      <motion.h1
        className="text-5xl font-extrabold text-center mb-16 tracking-tight"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        Past Events
      </motion.h1>

      {/* All Events Section */}
      <motion.div
        className="grid gap-10 sm:grid-cols-2 lg:grid-cols-3"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={{
          hidden: {},
          visible: { transition: { staggerChildren: 0.25 } },
        }}
      >
        {pastEvents.map((event, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            whileHover={{ scale: 1.05 }}
            className="bg-white/10 backdrop-blur-xl rounded-xl p-6 border border-white/20 shadow-lg hover:shadow-xl transition"
          >
            <EventCard
              title={event.title}
              date={event.date}
              description={event.description}
              image={event.image}

            />
          </motion.div>
        ))}
      </motion.div>

      {/* Divider */}
      <div className="my-24 text-center relative">
        <div className="h-[2px] w-3/4 mx-auto bg-gradient-to-r from-transparent via-[#FFD700] to-transparent"></div>
        <span className="absolute left-1/2 -translate-x-1/2 -translate-y-4 px-4 bg-[#0a0f1a] text-[#FFD700] text-lg font-semibold">
          Upcoming Events
        </span>
      </div>

      {/* Upcoming Events */}
      <motion.div
        className="grid gap-10 sm:grid-cols-2 lg:grid-cols-2 mb-24"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={{
          hidden: {},
          visible: { transition: { staggerChildren: 0.2 } },
        }}
      >
        {upcomingEvents.map((event, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            whileHover={{ scale: 1.05 }}
            className="relative overflow-hidden rounded-3xl bg-white/10 backdrop-blur-xl border border-white/20 shadow-lg hover:shadow-2xl transition-all"
          >
            <EventCard
              title={event.title}
              date={event.date}
              description={event.description}
              image={event.image}
             
            />
            {/* glowing overlay accent */}
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 bg-gradient-to-r from-sky-500/10 to-indigo-500/10 transition-all duration-700"></div>
          </motion.div>
        ))}
      </motion.div>

      {/* Call to Action */}
      <motion.div
        className="mt-16 p-10 rounded-3xl bg-white/10 backdrop-blur-xl border border-white/20 text-center shadow-2xl max-w-3xl mx-auto"
        initial={{ scale: 0.9, opacity: 0 }}
        whileInView={{ scale: 1, opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.3 }}
      >
        <h3 className="text-3xl font-bold mb-4 text-[#FFD700] tracking-wide">
          Stay Updated!
        </h3>
        <p className="text-white/80 mb-6 text-lg">
          Join the CS Society to get notifications about upcoming events, workshops,
          and competitions.
        </p>
        <a
          href="/register"
          className="px-8 py-3 text-black font-semibold rounded-full bg-gradient-to-r from-[#FFD700] to-[#ffb700] shadow-lg hover:shadow-[#FFD700]/50 hover:scale-105 transition-transform"
        >
          Subscribe Now
        </a>
      </motion.div>
    </div>
  );
}
