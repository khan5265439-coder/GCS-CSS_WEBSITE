import { useEffect, useState } from "react";
import { motion } from "framer-motion";

export default function Memberships() {
  const [memberships, setmemberships] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!localStorage.getItem("adminToken")) {
      window.location.href = "/admin";
    }
  }, []);

  const fetchmemberships = async () => {
    try {
     const res = await fetch("http://localhost:3001/api/register/all", {
  headers: {
    "x-admin-token": localStorage.getItem("adminToken"),
    "x-admin-email": localStorage.getItem("adminEmail"), 
  },
});


      const data = await res.json();
      setmemberships(data);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchmemberships();
  }, []);

  return (
    <div className="min-h-screen pt-28 pb-16 px-4 md:px-20 lg:px-32 bg-[#001a33] text-white relative overflow-hidden">
      {/* BACKGROUND GLOWS */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute w-80 h-80 bg-[#FFD700]/20 blur-[140px] top-10 left-6" />
        <div className="absolute w-80 h-80 bg-[#003366]/45 blur-[160px] bottom-8 right-4" />
      </div>

      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-4xl md:text-5xl font-bold text-center text-[#FFD700] drop-shadow-xl"
      >
       All memberships
      </motion.h1>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="text-center text-gray-200 mt-3 max-w-2xl mx-auto"
      >
        View all registered students for upcoming events.
      </motion.p>

      {/* LOADING */}
      {loading && (
        <motion.p
          className="text-center mt-10 text-gray-300"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          Loading memberships...
        </motion.p>
      )}

      {/* TABLE */}
      {!loading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          className="mt-10 overflow-x-auto bg-white/10 backdrop-blur-xl p-6 rounded-2xl border border-white/10 shadow-[0_0_30px_rgba(0,0,0,0.7)]"
        >
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-white/20 text-[#FFD700]">
                <th className="p-3">Name</th>
                <th className="p-3">Roll No</th>
                <th className="p-3">Email</th>
                <th className="p-3">Department</th>
                <th className="p-3">Semester</th>
                <th className="p-3">Post</th>
                <th className="p-3">Message</th>
              </tr>
            </thead>

            <tbody>
              {memberships.map((reg) => (
                <motion.tr
                  key={reg._id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.4 }}
                  className="border-b border-white/10 hover:bg-white/5 transition"
                >
                  <td className="p-3">{reg.name}</td>
                  <td className="p-3">{reg.rollNo}</td>
                  <td className="p-3">{reg.email}</td>
                  <td className="p-3">{reg.department}</td>
                  <td className="p-3">{reg.semester}</td>
                  <td className="p-3 text-[#FFD700] font-semibold">
                    {reg.post}
                  </td>
                  <td className="p-3">{reg.message || "—"}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      )}
    </div>
  );
}
