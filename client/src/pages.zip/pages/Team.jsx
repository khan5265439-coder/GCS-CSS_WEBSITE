import React from "react";
import TeamCard from "../components/TeamCard";
import { motion } from "framer-motion";

const teamMembers = [
  {
    name: "Touseef Iftikhar",
    role: "Advisor",
    photo: "src/assets/images/team1.png",
  },
  {
    name: "Maryam",
    role: "President",
    photo: "src/assets/images/team2.jpeg",
  },
  {
    name: "Zain Amir",
    role: "Vice President",
    photo: "src/assets/images/team3.png",
  },
  {
    name: "Rabail Ali",
    role: "Tech Lead",
    photo: "src/assets/images/team4.png",
  },
  {
    name: "Hassan Shah",
    role: "Marketing Head",
    photo: "src/assets/images/team5.png",
  },
  {
    name: "Sara Ali",
    role: "Designer",
    photo: "src/assets/images/team6.png",
  },
];

export default function Team() {
  return (
    <div className="page-container px-6 py-20 max-w-6xl mx-auto">
      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.3}}
        className="text-4xl font-bold text-center mb-12"
      >
        Meet the Team
      </motion.h1>

      <motion.div
        className="grid gap-10 md:grid-cols-2 lg:grid-cols-3"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={{
          hidden: {},
          visible: {
            transition: { staggerChildren: 0.2 },
          },
        }}
      >
        {teamMembers.map((member, index) => (
          <TeamCard
            key={index}
            name={member.name}
            role={member.role}
            photo={member.photo}
          />
        ))}
      </motion.div>

      {/* Call to Action */}
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        whileInView={{ scale: 1, opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.3 }}
        className="glass mt-20 p-10 rounded-3xl text-center shadow-xl max-w-2xl mx-auto"
      >
        <h3 className="text-3xl font-bold mb-4">
          Want to Join Our Team?
        </h3>
        <p className="text-white/70 mb-6">
          Become a member of the CS Society and help organize amazing tech events, workshops, and projects at GCU Lahore!
        </p>
        <button 
          Apply Now
          className="px-8 py-3 bg-gradient-to-r from-sky-500 to-indigo-600 text-white font-semibold rounded-full shadow-lg hover:shadow-sky-500/50 hover:scale-105 transition-transform"
        >
          Apply Now
          
        </button>
      </motion.div>
    </div>
  );
}
