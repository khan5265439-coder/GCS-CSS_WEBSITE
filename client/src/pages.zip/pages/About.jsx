import React from "react";
import { motion } from "framer-motion";

export default function About() {
  return (
    <div className="min-h-screen pt-[var(--navbar-height)] pb-20 px-4 md:px-12 lg:px-20 bg-[#001a33] text-white relative overflow-hidden">

      {/* BACKGROUND GLOWS */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[350px] h-[350px] bg-[#FFD700]/15 blur-[150px] rounded-full"></div>
        <div className="absolute bottom-0 right-0 w-[420px] h-[420px] bg-[#003366]/35 blur-[170px] rounded-full"></div>
      </div>

      {/* TITLE SECTION */}
      <motion.div
        initial={{ opacity: 0, y: 35 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="relative z-10 text-center max-w-5xl mx-auto mt-6"
      >
        <h1 className="text-5xl md:text-5xl font-bold text-[#FFD700] drop-shadow-[0_0_15px_rgba(255,215,0,0.4)]">
          About The Society
        </h1>
        <p className="text-gray-200 mt-4 text-base md:text-lg leading-relaxed">
          The Computer Science Society (CSS) at GCU Lahore is a vibrant student-led
          organization dedicated to promoting innovation, leadership, and technical
          excellence among computing students.
        </p>
      </motion.div>

      {/* MISSION & VISION SECTION */}
      <div className="relative z-10 mt-16 grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Mission */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="bg-white/5 border border-white/10 backdrop-blur-xl p-6 rounded-2xl shadow-[0_0_25px_rgba(0,0,0,0.5)]
                     hover:shadow-[0_0_25px_rgba(255,215,0,0.35)] transition-all duration-200"
        >
          <h2 className="text-2xl font-semibold text-[#FFD700] mb-3">Our Mission</h2>
          <p className="text-gray-200 leading-relaxed text-sm sm:text-base">
            To empower students with the knowledge, tools, and opportunities needed
            to excel in the ever-evolving fields of computer science and technology.
            We foster a culture of creativity, collaboration, and hands-on learning.
          </p>
        </motion.div>

        {/* Vision */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="bg-white/5 border border-white/10 backdrop-blur-xl p-6 rounded-2xl shadow-[0_0_25px_rgba(0,0,0,0.5)]
                     hover:shadow-[0_0_25px_rgba(255,215,0,0.35)] transition-all duration-200"
        >
          <h2 className="text-2xl font-semibold text-[#FFD700] mb-3">Our Vision</h2>
          <p className="text-gray-200 leading-relaxed text-sm sm:text-base">
            To create one of the most impactful and forward-thinking student societies
            in Pakistan — where every aspiring technologist finds guidance, exposure,
            and opportunities to grow.
          </p>
        </motion.div>

      </div>

      {/* OBJECTIVES SECTION */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="relative z-10 mt-20"
      >
        <h2 className="text-3xl font-semibold text-center text-[#FFD700]">
          Our Goals & Objectives
        </h2>

        <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-8">

          {/* Objective Card */}
          <div className="bg-white/5 border border-white/10 backdrop-blur-xl p-6 rounded-xl shadow-[0_0_25px_rgba(0,0,0,0.5)]
                          hover:shadow-[0_0_22px_rgba(255,215,0,0.35)] transition-all duration-200">
            <h3 className="text-lg font-semibold text-[#FFD700] mb-2">Skill Development</h3>
            <p className="text-gray-200 text-sm leading-relaxed">
              Conduct workshops and bootcamps to strengthen students’ practical
              understanding of AI, Web, Cyber Security, Cloud and Data Science.
            </p>
          </div>

          <div className="bg-white/5 border border-white/10 backdrop-blur-xl p-6 rounded-xl shadow-[0_0_25px_rgba(0,0,0,0.5)]
                          hover:shadow-[0_0_22px_rgba(255,215,0,0.35)] transition-all duration-200">
            <h3 className="text-lg font-semibold text-[#FFD700] mb-2">Community Building</h3>
            <p className="text-gray-200 text-sm leading-relaxed">
              Create an inclusive environment where students from all backgrounds
              collaborate, network, and learn from one another.
            </p>
          </div>

          <div className="bg-white/5 border border-white/10 backdrop-blur-xl p-6 rounded-xl shadow-[0_0_25px_rgba(0,0,0,0.5)]
                          hover:shadow-[0_0_22px_rgba(255,215,0,0.35)] transition-all duration-200">
            <h3 className="text-lg font-semibold text-[#FFD700] mb-2">Innovation & Leadership</h3>
            <p className="text-gray-200 text-sm leading-relaxed">
              Encourage students to take initiative, lead events, develop projects,
              and participate in national-level competitions.
            </p>
          </div>

        </div>
      </motion.div>

      {/* HISTORY SECTION */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="relative z-10 mt-20 bg-white/5 border border-white/10 backdrop-blur-xl p-8 rounded-2xl shadow-[0_0_25px_rgba(0,0,0,0.5)]
                   hover:shadow-[0_0_25px_rgba(255,215,0,0.35)] transition-all duration-200 max-w-5xl mx-auto"
      >
        <h2 className="text-3xl font-semibold text-[#FFD700] mb-4 text-center">
          A Brief History
        </h2>

        <p className="text-gray-200 text-sm md:text-base leading-relaxed">
          The Computer Science Society at GCU Lahore has played a pivotal role in
          supporting and uplifting young technologists across the university. From
          hosting Pakistan’s largest student-led tech competitions to facilitating
          skill-building workshops, CSS continues to evolve and adapt to emerging
          technologies — empowering students every step of the way.
        </p>
      </motion.div>

    </div>
  );
}
