import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import EventCard from "../components/EventCard";

const featuredEvents = [
  {
    title: "Hackathon 2025",
    text: "48 hours of coding, innovation, collaboration and creativity!",
    photo: "/hackathon.jpeg",
  },
  {
    title: "AI Workshop",
    text: "Hands-on introduction to Machine Learning and Neural Networks.",
    photo: "/ai.jpeg",
  },
  {
    title: "Cybersecurity Seminar",
    text: "Understanding ethical hacking and modern defense strategies.",
    photo: "/cyber.jpeg",
  },
];

export default function Home() {
  const [showParticles, setShowParticles] = useState(false);

  // Delay particles so main content loads instantly
  useEffect(() => {
    const timer = setTimeout(() => setShowParticles(true), 350);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#001a33] via-[#002244] to-[#0a0f1a] text-white overflow-hidden">

      {/* HERO SECTION */}
      <div className="relative w-full h-[92vh] flex flex-col items-center justify-center px-4">

        {/* 🔵 BLUE GLOW */}
        {showParticles && (
          <motion.div
            className="absolute w-[280px] h-[280px] sm:w-[380px] sm:h-[380px] md:w-[550px] md:h-[550px] rounded-full bg-blue-500/25 blur-[140px] pointer-events-none"
            animate={{ scale: [1, 1.25, 1] }}
            transition={{ duration: 7, repeat: Infinity }}
          />
        )}

        {/* 🟦 CYAN GLOW */}
        {showParticles && (
          <motion.div
            className="absolute w-[200px] h-[200px] sm:w-[300px] sm:h-[300px] md:w-[450px] md:h-[450px] rounded-full bg-cyan-400/15 blur-[110px] pointer-events-none"
            animate={{ scale: [1.2, 1, 1.2] }}
            transition={{ duration: 8, repeat: Infinity }}
          />
        )}

        {/* ⭐ RESPONSIVE LOGO */}
        <motion.div
          className="
            absolute z-10
            top-16 left-1/2 -translate-x-1/2
            sm:top-10
            md:top-14 md:left-16 md:translate-x-0
          "
          initial={{ opacity: 0, y: -25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9 }}
        >
          <img
            src="/logo.jpg"
            alt="CSS Logo"
            className="
              w-20 sm:w-24 md:w-32 lg:w-36
              rounded-full border-4 border-[#FFD700]/30 
              shadow-[0_0_20px_rgba(255,215,0,0.4)]
              hover:scale-[1.05] transition
            "
          />
        </motion.div>

        {/* ⭐ HERO TEXT */}
        <motion.div
          className="mt-40 md:mt-0 text-center max-w-3xl px-4"
          initial={{ opacity: 0, y: 70 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
        >
          <h1 className="text-4xl sm:text-5xl md:text-7xl font-extrabold leading-tight drop-shadow-2xl">
            Computer <span className="text-[#FFD700]">Science</span> Society
          </h1>

          <p className="mt-6 text-white/80 text-base sm:text-lg md:text-xl">
            Inspiring and empowering tech enthusiasts at GCU Lahore — through
            workshops, competitions, seminars, bootcamps, and a thriving community culture.
          </p>

          {/* ⭐ BUTTONS */}
          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <a
              href="/events"
              className="px-6 py-3 rounded-full bg-gradient-to-r from-sky-600 to-indigo-600 text-white font-semibold shadow-lg hover:shadow-sky-500/50 hover:scale-[1.05] transition"
            >
              Explore Events
            </a>

            <a
              href="/team"
              className="px-6 py-3 rounded-full border border-white/40 text-white font-medium hover:bg-white/10 backdrop-blur-md transition"
            >
              Meet the Team
            </a>
          </div>
        </motion.div>
      </div>

      {/* ⭐ FEATURED EVENTS SECTION */}
      <div className="px-4 sm:px-6 py-24 max-w-6xl mx-auto">
        <motion.h2
          className="text-3xl sm:text-4xl font-bold text-center mb-14"
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
        >
          Highlights
        </motion.h2>

        <motion.div
          className="grid gap-6 sm:gap-10 sm:grid-cols-2 lg:grid-cols-3"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={{
            hidden: {},
            visible: { transition: { staggerChildren: 0.25 } },
          }}
        >
          {featuredEvents.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              whileHover={{ scale: 1.05 }}
              className="bg-white/10 backdrop-blur-xl rounded-xl p-6 border border-white/20 shadow-lg hover:shadow-xl transition"
            >
              <EventCard
                title={item.title}
                description={item.text}
                image={item.photo}
              />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}
