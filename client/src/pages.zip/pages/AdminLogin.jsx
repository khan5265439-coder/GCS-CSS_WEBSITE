import { useState } from "react";

export default function AdminLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleLogin = async (e) => {
    e.preventDefault();

    const res = await fetch("http://localhost:3001/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    const data = await res.json();

    if (!data.success) return setError("Invalid email or password");

    localStorage.setItem("adminToken", data.token);
localStorage.setItem("adminEmail", email);


    window.location.href = "/all-registrations";
  
  };

  return (
    <div className="min-h-screen flex justify-center items-center bg-[#001a33] text-white">
      <form
        onSubmit={handleLogin}
        className="bg-white/10 p-8 rounded-xl shadow-xl backdrop-blur-lg border border-white/20"
      >
        <h1 className="text-3xl font-bold text-[#FFD700] mb-4">Admin Login</h1>

        {error && <p className="text-red-400 mb-2">{error}</p>}

        <input
          type="email"
          placeholder="Admin Email"
          className="w-full mb-3 p-3 bg-[#001427] border border-white/20 rounded"
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          className="w-full mb-4 p-3 bg-[#001427] border border-white/20 rounded"
          onChange={(e) => setPassword(e.target.value)}
        />

        <button
          className="w-full bg-[#FFD700] text-black font-semibold py-2 rounded"
        >
          Login
        </button>
      </form>
    </div>
  );
}
