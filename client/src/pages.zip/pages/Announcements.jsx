import React from "react";
import { motion } from "framer-motion";

const announcements = [
  {
    title: "New Recruitment Drive Open!",
    date: "10 Nov 2025",
    type: "Notice",
    description:
      "Join the CS Society core team! We’re looking for passionate developers, designers, and content creators. Apply before 20 Nov 2025.",
    icon: "📣",
  },
  {
    title: "AI Bootcamp Registrations Closing Soon",
    date: "12 Nov 2025",
    type: "Update",
    description:
      "Limited seats left for the AI Bootcamp! Don’t miss the opportunity to learn hands-on AI and Machine Learning.",
    icon: "🤖",
  },
  {
    title: "Hackathon 2025 Pre-Event Meetup",
    date: "14 Nov 2025",
    type: "Event",
    description:
      "All registered teams are invited to the Hackathon briefing session on 14th Nov at 3 PM, Lab-2, CS Department.",
    icon: "⚡",
  },
];

export default function Announcements() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-[#001a33] via-[#002244] to-[#0a0f1a] text-white px-6 py-20">
      
      {/* Page Header */}
      <motion.h1
        className="text-5xl font-extrabold text-center mb-16 tracking-tight"
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        Announcements & Notices
      </motion.h1>

      {/* Grid */}
      <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-3 max-w-6xl mx-auto">
        {announcements.map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.3 }}
            whileHover={{ scale: 1.05 }}
            className="relative p-8 rounded-3xl bg-white/10 backdrop-blur-xl border border-white/20 shadow-lg hover:shadow-2xl transition-all"
          >
            <div className="flex items-center gap-4 mb-4">
              <div className="text-4xl">{item.icon}</div>
              <div>
                <h3 className="text-xl font-semibold text-[#FFD700]">{item.title}</h3>
                <p className="text-sm text-white/60">{item.date}</p>
              </div>
            </div>

            <p className="text-white/80 leading-relaxed mb-4">{item.description}</p>

            <span
              className={`inline-block px-4 py-1 text-sm font-medium rounded-full ${
                item.type === "Notice"
                  ? "bg-pink-500/20 text-pink-300"
                  : item.type === "Update"
                  ? "bg-cyan-500/20 text-cyan-300"
                  : "bg-yellow-500/20 text-yellow-300"
              }`}
            >
              {item.type}
            </span>
          </motion.div>
        ))}
      </div>

      {/* CTA */}
      <motion.div
        className="mt-24 p-10 rounded-3xl bg-white/10 backdrop-blur-xl border border-white/20 text-center shadow-2xl max-w-3xl mx-auto"
        initial={{ scale: 0.9, opacity: 0 }}
        whileInView={{ scale: 1, opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.3 }}
      >
        <h3 className="text-3xl font-bold mb-4 text-[#FFD700]">Stay Updated!</h3>
        <p className="text-white/80 mb-6 text-lg">
          Subscribe to our mailing list to receive important updates, workshops, and notices.
        </p>
        <a
          href="/contact"
          className="px-8 py-3 text-black font-semibold rounded-full bg-gradient-to-r from-[#FFD700] to-[#ffb700] shadow-lg hover:scale-105 transition-transform"
        >
          Subscribe Now
        </a>
      </motion.div>
    </div>
  );
}
