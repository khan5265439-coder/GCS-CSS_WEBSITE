import React, { useState } from "react";
import { motion } from "framer-motion";

export default function Contact() {
  const [formData, setFormData] = useState({ name: "", email: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form Submitted:", formData);
    setSubmitted(true);
    setFormData({ name: "", email: "", message: "" });
    setTimeout(() => setSubmitted(false), 4000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#001a33] via-[#002244] to-[#0a0f1a] text-white px-6 py-20">
      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.3 }}
        className="text-5xl font-extrabold text-center mb-16 tracking-tight"
      >
        Get In <span className="text-[#FFD700]">Touch</span>
      </motion.h1>

      <motion.div
        className="flex flex-col md:flex-row gap-10 max-w-5xl mx-auto"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.3 }}
      >
        {/* Contact Info */}
        <div className="flex-1 bg-white/10 backdrop-blur-xl p-8 rounded-3xl border border-white/20 shadow-xl hover:shadow-2xl transition-all">
          <h2 className="text-2xl font-semibold text-[#FFD700] mb-4">
            Contact Information
          </h2>
          <p className="text-white/80 mb-2">Computer Science Society, GCU Lahore</p>
          <p className="text-white/80 mb-2">Email: cs-society@gcu.edu.pk</p>
          <p className="text-white/80 mb-6">Phone: +92 300 1234567</p>

          <div className="flex gap-5 mt-4 justify-start">
            {[
              { name: "Instagram", link: "#", color: "from-pink-500 to-orange-400" },
              { name: "Twitter", link: "#", color: "from-sky-500 to-blue-400" },
              { name: "LinkedIn", link: "#", color: "from-blue-600 to-cyan-500" },
            ].map((social, index) => (
              <a
                key={index}
                href={social.link}
                target="_blank"
                rel="noopener noreferrer"
                className={`px-4 py-2 rounded-full bg-gradient-to-r ${social.color} text-white font-medium shadow-md hover:shadow-lg hover:scale-105 transition-transform text-sm`}
              >
                {social.name}
              </a>
            ))}
          </div>
        </div>

        {/* Contact Form */}
        <form
          onSubmit={handleSubmit}
          className="flex-1 bg-white/10 backdrop-blur-xl p-8 rounded-3xl border border-white/20 shadow-xl flex flex-col gap-4 hover:shadow-2xl transition-all"
        >
          {submitted && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-green-400 font-semibold text-center"
            >
              Message sent successfully!
            </motion.p>
          )}

          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Your Name"
            className="p-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-sky-500 transition"
            required
          />
          <input
            type="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Your Email"
            className="p-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-sky-500 transition"
            required
          />
          <textarea
            name="message"
            value={formData.message}
            onChange={handleChange}
            placeholder="Your Message"
            rows="5"
            className="p-3 rounded-lg bg-white/10 border border-white/20 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-sky-500 transition resize-none"
            required
          ></textarea>

          <button
            type="submit"
            className="mt-4 px-8 py-3 bg-gradient-to-r from-[#FFD700] to-[#ffb700] text-black font-semibold rounded-full shadow-lg hover:shadow-[#FFD700]/40 hover:scale-105 transition-transform"
          >
            Send Message
          </button>
        </form>
      </motion.div>
    </div>
  );
}
